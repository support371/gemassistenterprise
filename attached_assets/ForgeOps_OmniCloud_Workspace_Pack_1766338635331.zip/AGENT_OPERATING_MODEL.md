# Agent Operating Model

## AgentRun Lifecycle
Intake → Plan → Execute → Verify → Propose → Deploy → Observe → Report

## Guardrails
- Least privilege tool access
- Approval gates for high-risk actions
- Immutable audit logs

## Deployment Rules
- Staging auto-deploy
- Production deploy requires approval
