# Security & Compliance Baseline

- RBAC enforced at org and project levels
- Secrets via environment variables only
- No keys in frontend code
- Audit log for all agent and deployment actions
- SOC 2 readiness by design
