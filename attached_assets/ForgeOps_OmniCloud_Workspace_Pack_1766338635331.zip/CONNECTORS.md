# Connector Interfaces

Each integration must be implemented as an adapter:
- GitHubAdapter
- VercelAdapter
- CloudflareAdapter
- OpenAIAdapter
- GeminiAdapter
- CloudProviderAdapter (AWS/GCP/Azure)
- DockerAdapter

Adapters must be stateless and config-driven.
