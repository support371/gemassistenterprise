# CI/CD Strategy

## CI
- Lint
- Unit tests
- Secret scanning

## CD
- Vercel Git-based deploys
- Backend container deploys
- Rollback supported

All pipelines must be reproducible.
