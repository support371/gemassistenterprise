# Operations Runbook

## Environments
- Dev
- Staging
- Production

## Incident Response
Detect → Triage → Mitigate → Review

## Backups
- Daily DB snapshots
- Restore tested quarterly
