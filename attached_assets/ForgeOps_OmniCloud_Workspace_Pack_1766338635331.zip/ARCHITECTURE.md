# System Architecture

## Frontend
- Next.js (Vercel deployment)

## Backend
- FastAPI (Dockerized)
- Postgres (system of record)

## Agent Layer
- Agent Orchestrator
- Task Graph Engine
- Policy & Approval Engine

## Integrations
GitHub, Vercel, Cloudflare, OpenAI, Gemini, AWS, Azure, GCP, Firebase, Docker
