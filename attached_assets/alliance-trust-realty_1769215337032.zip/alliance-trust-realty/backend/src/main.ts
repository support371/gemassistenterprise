import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';

async function bootstrap() {
  // Create the NestJS application
  const app = await NestFactory.create(AppModule);

  // Enable CORS for the frontend running on localhost:3000
  app.enableCors({
    origin: 'http://localhost:3000',
    credentials: true,
  });

  // Use a global validation pipe to automatically validate request DTOs
  app.useGlobalPipes(new ValidationPipe());

  // Start listening on the configured port
  const port = process.env.PORT || 4000;
  await app.listen(port);
  console.log(`🚀 Backend running on http://localhost:${port}`);
}

bootstrap();