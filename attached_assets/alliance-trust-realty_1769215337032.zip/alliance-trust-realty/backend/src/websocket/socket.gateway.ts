import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

@WebSocketGateway({ cors: { origin: 'http://localhost:3000' } })
export class SocketGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  // Map of user IDs to their active socket connection IDs
  private userSockets = new Map<string, string>();

  // Fired when a client first connects to the WebSocket server
  handleConnection(client: Socket) {
    console.log(`Client connected: ${client.id}`);
  }

  // Fired when a client disconnects from the WebSocket server
  handleDisconnect(client: Socket) {
    console.log(`Client disconnected: ${client.id}`);
    // Remove any stored reference for the disconnected client
    this.userSockets.forEach((socketId, userId) => {
      if (socketId === client.id) {
        this.userSockets.delete(userId);
      }
    });
  }

  // SubscribeMessage decorator listens for a 'join-portfolio' event
  @SubscribeMessage('join-portfolio')
  handleJoinPortfolio(client: Socket, userId: string) {
    // Store the mapping of user ID to socket ID for later use
    this.userSockets.set(userId, client.id);
    // Put the socket in a room specific to the user
    client.join(`portfolio-${userId}`);
  }

  /**
   * Emit a WebSocket event to a specific user
   *
   * @param userId The user identifier
   * @param event The name of the event to emit
   * @param data The data payload to send
   */
  emitToUser(userId: string, event: string, data: any) {
    this.server.to(`portfolio-${userId}`).emit(event, data);
  }
}