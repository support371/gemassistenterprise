import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Property } from '../../properties/entities/property.entity';

@Entity('investments')
export class Investment {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column('uuid')
  user_id: string;

  @Column('uuid')
  property_id: string;

  @Column('decimal', { precision: 12, scale: 2 })
  investment_amount: number;

  @Column('decimal', { precision: 5, scale: 2, nullable: true })
  ownership_percentage: number;

  @Column({ type: 'enum', enum: ['pending', 'active', 'sold', 'cancelled'], default: 'pending' })
  status: string;

  @Column('date')
  start_date: Date;

  @Column('decimal', { precision: 12, scale: 2, nullable: true })
  current_value: number;

  @Column('decimal', { precision: 12, scale: 2, default: 0 })
  total_distributions: number;

  @Column('decimal', { precision: 5, scale: 2, nullable: true })
  current_roi: number;

  @Column('jsonb', { nullable: true })
  mortgage_data: any;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'user_id' })
  user: User;

  @ManyToOne(() => Property)
  @JoinColumn({ name: 'property_id' })
  property: Property;

  @CreateDateColumn()
  created_at: Date;
}