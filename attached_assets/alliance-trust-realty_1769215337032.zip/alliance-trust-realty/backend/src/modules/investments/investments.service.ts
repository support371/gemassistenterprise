import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Investment } from './entities/investment.entity';
import { Property } from '../properties/entities/property.entity';

@Injectable()
export class InvestmentsService {
  constructor(
    @InjectRepository(Investment)
    private investmentsRepository: Repository<Investment>,
    @InjectRepository(Property)
    private propertiesRepository: Repository<Property>,
  ) {}

  /**
   * Get a portfolio summary and individual investment metrics for a given user.
   *
   * @param userId The ID of the user whose portfolio is being fetched
   */
  async getPortfolio(userId: string) {
    const investments = await this.investmentsRepository.find({
      where: { user_id: userId },
      relations: ['property'],
    });

    const totalInvested = investments.reduce(
      (sum, inv) => sum + Number(inv.investment_amount),
      0,
    );
    const currentValue = investments.reduce(
      (sum, inv) => sum + Number(inv.current_value || inv.investment_amount),
      0,
    );
    const totalReturn = currentValue - totalInvested;
    const totalROI = (totalReturn / totalInvested) * 100;

    return {
      summary: {
        totalInvested,
        currentPortfolioValue: currentValue,
        totalReturn,
        totalROI,
        activeProperties: investments.filter((i) => i.status === 'active').length,
      },
      investments: investments.map((inv) => ({
        ...inv,
        metrics: {
          currentValue: inv.current_value || inv.investment_amount,
          totalReturn: (inv.current_value || inv.investment_amount) - inv.investment_amount,
          roi: inv.current_roi || 0,
        },
      })),
    };
  }

  /**
   * Create a new investment for a user in a property.
   *
   * @param userId The user making the investment
   * @param propertyId The property being invested in
   * @param amount The amount invested
   */
  async createInvestment(userId: string, propertyId: string, amount: number) {
    // Ensure the property exists
    const property = await this.propertiesRepository.findOne({ where: { id: propertyId } });

    const investment = this.investmentsRepository.create({
      user_id: userId,
      property_id: propertyId,
      investment_amount: amount,
      ownership_percentage: 100,
      status: 'active',
      start_date: new Date(),
      current_value: amount,
      current_roi: 0,
    });

    return this.investmentsRepository.save(investment);
  }
}