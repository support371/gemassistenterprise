import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity('properties')
export class Property {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  address: string;

  @Column()
  city: string;

  @Column()
  state: string;

  @Column()
  zip_code: string;

  @Column({ type: 'enum', enum: ['single_family', 'multi_family', 'condo', 'commercial'] })
  property_type: string;

  @Column('decimal', { precision: 12, scale: 2 })
  list_price: number;

  @Column('decimal', { precision: 12, scale: 2, nullable: true })
  current_value: number;

  @Column('decimal', { precision: 3, scale: 1, nullable: true })
  bedrooms: number;

  @Column('decimal', { precision: 3, scale: 1, nullable: true })
  bathrooms: number;

  @Column({ nullable: true })
  square_feet: number;

  @Column({ nullable: true })
  year_built: number;

  @Column('decimal', { precision: 10, scale: 2, nullable: true })
  property_tax_annual: number;

  @Column('decimal', { precision: 10, scale: 2, nullable: true })
  insurance_annual: number;

  @Column('decimal', { precision: 10, scale: 2, nullable: true })
  estimated_monthly_rent: number;

  @Column('decimal', { precision: 10, scale: 2, nullable: true })
  actual_monthly_rent: number;

  @Column('decimal', { precision: 5, scale: 2, nullable: true })
  cap_rate: number;

  @Column('jsonb', { nullable: true })
  images: any;

  @Column('jsonb', { nullable: true })
  features: any;

  @Column('text', { nullable: true })
  description: string;

  @CreateDateColumn()
  created_at: Date;
}