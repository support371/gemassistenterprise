import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { User } from '../users/entities/user.entity';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User)
    private usersRepository: Repository<User>,
    private jwtService: JwtService,
  ) {}

  /**
   * Registers a new user in the system.
   *
   * @param email The user's email address
   * @param password The user's chosen password
   * @param firstName The user's first name
   * @param lastName The user's last name
   */
  async register(email: string, password: string, firstName: string, lastName: string) {
    // Hash the plain-text password
    const hashedPassword = await bcrypt.hash(password, 10);

    const user = this.usersRepository.create({
      email,
      password_hash: hashedPassword,
      first_name: firstName,
      last_name: lastName,
      role: 'investor',
    });

    // Persist the new user to the database
    await this.usersRepository.save(user);

    // Generate a signed JWT for the new user
    const token = this.jwtService.sign({ sub: user.id, email: user.email });

    return {
      user: { id: user.id, email: user.email, role: user.role },
      token,
    };
  }

  /**
   * Logs a user in and returns a JWT if the credentials are valid.
   *
   * @param email The user's email address
   * @param password The user's password
   */
  async login(email: string, password: string) {
    const user = await this.usersRepository.findOne({ where: { email } });

    // Validate that the user exists and the password matches
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      throw new UnauthorizedException('Invalid credentials');
    }

    // Sign a new JWT token for the user
    const token = this.jwtService.sign({ sub: user.id, email: user.email });

    return {
      user: { id: user.id, email: user.email, role: user.role },
      token,
    };
  }
}