import { Module } from '@nestjs/common';

/**
 * The AnalyticsModule is a stub for future analytics functionality. This
 * module could aggregate investment data, provide reporting, and expose
 * dashboards. For now it simply exists to satisfy module imports in the
 * AppModule.
 */
@Module({})
export class AnalyticsModule {}