-- PostgreSQL schema for Alliance Trust Realty

CREATE DATABASE alliance_trust_realty;
\c alliance_trust_realty;

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ENUMS
CREATE TYPE user_role AS ENUM ('investor', 'agent', 'admin');
CREATE TYPE property_type AS ENUM ('single_family', 'multi_family', 'condo', 'commercial');
CREATE TYPE investment_status AS ENUM ('pending', 'active', 'sold', 'cancelled');

-- USERS TABLE
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    role user_role DEFAULT 'investor',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- PROPERTIES TABLE
CREATE TABLE properties (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    address VARCHAR(255) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(2) NOT NULL,
    zip_code VARCHAR(10) NOT NULL,
    property_type property_type NOT NULL,
    list_price DECIMAL(12, 2) NOT NULL,
    current_value DECIMAL(12, 2),
    bedrooms DECIMAL(3,1),
    bathrooms DECIMAL(3,1),
    square_feet INTEGER,
    year_built INTEGER,
    property_tax_annual DECIMAL(10, 2),
    insurance_annual DECIMAL(10, 2),
    estimated_monthly_rent DECIMAL(10, 2),
    actual_monthly_rent DECIMAL(10, 2),
    cap_rate DECIMAL(5, 2),
    images JSONB,
    features JSONB,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- INVESTMENTS TABLE
CREATE TABLE investments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    property_id UUID REFERENCES properties(id),
    investment_amount DECIMAL(12, 2) NOT NULL,
    ownership_percentage DECIMAL(5, 2),
    status investment_status DEFAULT 'pending',
    start_date DATE NOT NULL,
    current_value DECIMAL(12, 2),
    total_distributions DECIMAL(12, 2) DEFAULT 0,
    current_roi DECIMAL(5, 2),
    mortgage_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- TRANSACTIONS TABLE
CREATE TABLE transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    investment_id UUID REFERENCES investments(id),
    type VARCHAR(50) NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    description TEXT,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- PORTFOLIO SNAPSHOTS TABLE
CREATE TABLE portfolio_snapshots (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    snapshot_date DATE NOT NULL,
    total_invested DECIMAL(12, 2),
    current_portfolio_value DECIMAL(12, 2),
    total_roi DECIMAL(5, 2),
    monthly_cash_flow DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- NOTIFICATIONS TABLE
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    title VARCHAR(255),
    message TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_properties_city_state ON properties(city, state);
CREATE INDEX idx_investments_user ON investments(user_id);
CREATE INDEX idx_transactions_user ON transactions(user_id);