import { create } from 'zustand';

interface PortfolioState {
  totalValue: number;
  totalROI: number;
  monthlyIncome: number;
  activeProperties: number;
  investments: any[];
  updatePortfolio: (data: any) => void;
}

/**
 * Zustand store to track portfolio metrics and investment details. The
 * updatePortfolio method replaces the entire store state with new values.
 */
export const usePortfolioStore = create<PortfolioState>((set) => ({
  totalValue: 0,
  totalROI: 0,
  monthlyIncome: 0,
  activeProperties: 0,
  investments: [],
  updatePortfolio: (data) => set(data),
}));