import React from 'react';

/**
 * A simple Card component and its subcomponents used to compose the dashboard
 * cards. These components provide basic structure and styling. In a more
 * complete implementation you might pull these from a design system library.
 */
export function Card({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={`rounded-lg bg-white shadow-sm border border-gray-200 ${className || ''}`}
      {...props}
    />
  );
}

export function CardHeader({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={`p-4 border-b border-gray-100 flex items-center justify-between ${className || ''}`}
      {...props}
    />
  );
}

export function CardTitle({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return (
    <h3 className={`text-sm font-medium ${className || ''}`} {...props} />
  );
}

export function CardContent({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={`p-4 ${className || ''}`} {...props} />
  );
}