'use client';

import { useEffect, useState } from 'react';
import { useSocket } from '@/lib/hooks/useSocket';
import { usePortfolioStore } from '@/store/portfolioStore';
import { PortfolioOverview } from '@/components/dashboard/PortfolioOverview';
import apiClient from '@/lib/api/client';

export default function InvestorDashboard() {
  const socket = useSocket();
  const { totalValue, totalROI, monthlyIncome, activeProperties, updatePortfolio } = usePortfolioStore();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch initial portfolio data on mount
    apiClient.get('/investments/portfolio').then((res) => {
      updatePortfolio(res.data.summary);
      setLoading(false);
    });

    // Subscribe to real-time portfolio updates over WebSocket
    if (socket) {
      // Replace 'user-id' with the actual user ID when integrating auth
      socket.emit('join-portfolio', 'user-id');

      socket.on('portfolio-update', (data) => {
        updatePortfolio(data);
      });
    }

    return () => {
      if (socket) {
        socket.off('portfolio-update');
      }
    };
  }, [socket, updatePortfolio]);

  if (loading) return <div>Loading...</div>;

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Investment Dashboard</h1>
      <PortfolioOverview
        totalValue={totalValue}
        totalROI={totalROI}
        monthlyIncome={monthlyIncome}
        activeProperties={activeProperties}
      />
    </div>
  );
}