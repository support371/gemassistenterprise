export default function Home() {
  return (
    <main className="min-h-screen">
      <section className="py-20 px-4 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-5xl font-bold mb-6">Alliance Trust Realty</h1>
          <p className="text-xl mb-8">Full-Service Real Estate with Investment Expertise</p>
          <div className="flex gap-4 justify-center">
            <a href="/properties" className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold">
              Browse Properties
            </a>
            <a href="/dashboard/investor" className="bg-blue-500 px-8 py-3 rounded-lg font-semibold">
              Investor Dashboard
            </a>
          </div>
        </div>
      </section>
    </main>
  );
}