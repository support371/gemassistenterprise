import { useEffect, useState } from 'react';
import { io, Socket } from 'socket.io-client';

/**
 * Custom hook to manage a Socket.IO connection lifecycle. When the component mounts,
 * a new socket is created and stored in state. When the component unmounts, the
 * socket is disconnected. This hook returns the socket instance or null while
 * connecting.
 */
export function useSocket() {
  const [socket, setSocket] = useState<Socket | null>(null);

  useEffect(() => {
    const socketInstance = io(process.env.NEXT_PUBLIC_WS_URL || 'http://localhost:4000');
    setSocket(socketInstance);

    return () => {
      socketInstance.disconnect();
    };
  }, []);

  return socket;
}