/**
 * @type {import('next').NextConfig}
 */
const nextConfig = {
  reactStrictMode: true,
  // Enable experimental app directory support if needed
  experimental: {
    appDir: true,
  },
};

module.exports = nextConfig;